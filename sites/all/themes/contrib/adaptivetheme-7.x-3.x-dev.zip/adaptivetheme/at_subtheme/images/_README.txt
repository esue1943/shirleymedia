

Non CSS Images
--------------

This directory is for images that at are not used in CSS. By default
only the touch icons are included here. In short, if your image is 
loaded using an img or link element the image should be stored here.

Included by default are three Apple touch icon files, which you can edit or
replace if using touch icons (see your theme settings, under Extensions).
