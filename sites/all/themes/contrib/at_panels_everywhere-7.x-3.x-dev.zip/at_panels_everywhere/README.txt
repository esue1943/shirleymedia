
  WARNING: This theme has only one region (content), enabling this theme as default will render
  your site with no sidebars or any other regions! It is recommended that you set another theme
  as the Admin theme until you have Panels Everywhere set up correctly.
  
  For other issues please see the issue queue first and post a new issue if you still have a problem:
  http://drupal.org/project/issues/adaptivetheme

  For paid support, customizations and theme development please contact:

  Jeff Burnz
  Ph: +46 (0)40 693 63 11
  Mob: +46 (0)709 600 416
  Skype: jmburnz
  http://adaptivethemes.com/contact
  http://drupal.org/user/61393




